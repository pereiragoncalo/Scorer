extends Node3D
## Atleta 3D provisório, autonomo e sem assets licenciados.
## Mais tarde substituir malhas por atletas rigged .glb e AnimationTree.

var team_id: int = 0
var move_phase: float = 0.0
var walk_speed: float = 0.0
var left_leg: Node3D
var right_leg: Node3D
var left_arm: Node3D
var right_arm: Node3D
var body: Node3D
var shadow_disc: MeshInstance3D

func setup(number: int, shirt_color: Color, shorts_color: Color, team: int) -> void:
    team_id = team
    var skin: Color = Color("#d7a179")
    var shoe: Color = Color("#181e2d")
    body = Node3D.new()
    body.name = "Rig_Prototype"
    add_child(body)
    _box("Jersey", Vector3(0, 1.22, 0), Vector3(0.55, 0.64, 0.33), shirt_color, body)
    _box("Shorts", Vector3(0, 0.81, 0), Vector3(0.55, 0.25, 0.37), shorts_color, body)
    _sphere("Neck", Vector3(0, 1.65, 0), Vector3(0.13, 0.14, 0.13), skin, body)
    _sphere("Head", Vector3(0, 1.87, 0), Vector3(0.22, 0.26, 0.22), skin, body)
    _sphere("Hair", Vector3(0, 2.06, 0.02), Vector3(0.22, 0.11, 0.23), Color("#17212d"), body)
    _box("Number", Vector3(0, 1.26, -0.176), Vector3(0.18, 0.22, 0.022), Color("#f3f5fc"), body)
    left_leg = _joint("LeftLeg", Vector3(-0.16, 0.70, 0), body)
    right_leg = _joint("RightLeg", Vector3(0.16, 0.70, 0), body)
    _box("Sock", Vector3(0, -0.27, 0), Vector3(0.19, 0.5, 0.20), Color("#f3f7fb"), left_leg)
    _box("Boot", Vector3(0, -0.57, -0.11), Vector3(0.21, 0.14, 0.35), shoe, left_leg)
    _box("Sock", Vector3(0, -0.27, 0), Vector3(0.19, 0.5, 0.20), Color("#f3f7fb"), right_leg)
    _box("Boot", Vector3(0, -0.57, -0.11), Vector3(0.21, 0.14, 0.35), shoe, right_leg)
    left_arm = _joint("LeftArm", Vector3(-0.36, 1.48, 0), body)
    right_arm = _joint("RightArm", Vector3(0.36, 1.48, 0), body)
    _box("Sleeve", Vector3(0, -0.14, 0), Vector3(0.18, 0.32, 0.22), shirt_color, left_arm)
    _box("Hand", Vector3(0, -0.38, 0), Vector3(0.14, 0.26, 0.16), skin, left_arm)
    _box("Sleeve", Vector3(0, -0.14, 0), Vector3(0.18, 0.32, 0.22), shirt_color, right_arm)
    _box("Hand", Vector3(0, -0.38, 0), Vector3(0.14, 0.26, 0.16), skin, right_arm)
    left_arm.rotation.z = -0.15
    right_arm.rotation.z = 0.15
    shadow_disc = MeshInstance3D.new()
    shadow_disc.name = "ContactShadow"
    var disc: CylinderMesh = CylinderMesh.new()
    disc.top_radius = 0.36
    disc.bottom_radius = 0.36
    disc.height = 0.006
    shadow_disc.mesh = disc
    shadow_disc.material_override = _material(Color(0.015, 0.07, 0.05, 0.36), true)
    shadow_disc.position = Vector3(0, 0.03, 0)
    add_child(shadow_disc)
    set_meta("shirt_number", number)

func animate_motion(speed_ratio: float, delta: float) -> void:
    walk_speed = lerpf(walk_speed, clampf(speed_ratio, 0.0, 1.0), minf(1.0, delta * 9.0))
    move_phase += delta * (3.0 + 13.0 * walk_speed)
    var swing: float = sin(move_phase) * 0.70 * walk_speed
    left_leg.rotation.x = swing
    right_leg.rotation.x = -swing
    left_arm.rotation.x = -swing * 0.85
    right_arm.rotation.x = swing * 0.85
    body.position.y = absf(sin(move_phase)) * 0.055 * walk_speed

func _joint(label: String, at: Vector3, parent_node: Node3D) -> Node3D:
    var n: Node3D = Node3D.new()
    n.name = label
    n.position = at
    parent_node.add_child(n)
    return n

func _box(label: String, at: Vector3, dimensions: Vector3, tint: Color, parent_node: Node3D) -> void:
    var m: MeshInstance3D = MeshInstance3D.new()
    m.name = label
    var shape: BoxMesh = BoxMesh.new()
    shape.size = dimensions
    m.mesh = shape
    m.material_override = _material(tint)
    m.position = at
    parent_node.add_child(m)

func _sphere(label: String, at: Vector3, scale3d: Vector3, tint: Color, parent_node: Node3D) -> void:
    var m: MeshInstance3D = MeshInstance3D.new()
    m.name = label
    var shape: SphereMesh = SphereMesh.new()
    shape.radial_segments = 16
    shape.rings = 8
    m.mesh = shape
    m.material_override = _material(tint)
    m.scale = scale3d
    m.position = at
    parent_node.add_child(m)

func _material(tint: Color, transparent: bool = false) -> StandardMaterial3D:
    var material: StandardMaterial3D = StandardMaterial3D.new()
    material.albedo_color = tint
    material.metallic = 0.06
    material.roughness = 0.66
    if transparent:
        material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
        material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    return material
